﻿using ElectronicVotingSystemService.Data_Models;
using System.Collections.Generic;

namespace ElectronicVotingSystemService.HelperServices
{
    /// <summary>
    /// Framework for the Database Helper. The code in the front end services will remain uneffected
    /// by calling this interface if the back end database service has been tweaked. 
    /// </summary>
    public interface IDatabaseHelper
    {
        int AddUserToDatabase(User user);
        List<CountVote> CountVotesForElection(string electionInstanceID);
        int CreateNewVote(string electionInstanceID, string candidateID, string userID);
        List<Election> GetActiveElections();
        List<Election> GetAllElections();
        List<Election> GetAllElectionsDeleted();
        List<Election> GetAllElectionsNotDeleted();
        bool DoesElectionNameAlreadyExist(string electionName);
        Candidate GetCandidateFromElectionIDCandidateName(string electionInstanceID, string candidateName, int deleted = 0);
        Candidate GetCandidateFromElectionIDCandidateID(string electionInstanceID, string candidateID);
        List<User> GetNonAuthenticatedUsers();
        List<Candidate> GetCandidatesFromElection(string electionInstanceID);
        Election GetElectionFromElectionID(string electionInstanceID);
        User GetUser(string nationalInsuranceNumber, string password);
        bool IsValidUserCredentials(string nationalInsuranceNumber, string password);
        bool HasAdministratorAuthenticatedUser(string nationalInsuranceNumber, string password);
        List<User> GetAuthenticatedUsers();
        Vote GetUserVoteFromElection(string electionInstanceID, string userID);
        bool HasUserVotedForCandidate(string electionInstanceID, string candidateID, string userID);
        int UpdateVote(Vote vote, string candidateID);
        bool HasElectionEnded(string electionInstanceID);
        int DeleteElection(string electionInstanceID);
        User DoesUserAlreadyExist(string nationalInsuranceNumber);
        int AddElectionToDatabase(Election election);
        int RecoverElection(string electionInstanceID);
        List<Candidate> GetDeletedCandidatesFromElection(string electionInstanceID);
        User GetUserFromUserID(string userID);
        int AddCandidateToElection(string electionInstanceID, string candidateName);
        int DeleteCandidateFromElection(string candidateID);
        int RecoverCandidate(string candidateID);
        int SetUserAuthenticated(string userID);
        int UpdateUser(User user);
    }
}