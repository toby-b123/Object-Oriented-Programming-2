﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using ElectronicVotingSystemService.Data_Models;

namespace ElectronicVotingSystemService.HelperServices
{
    public class ValidatorHelper
    {
        private readonly IDatabaseHelper _databaseHelper;

        public ValidatorHelper(IDatabaseHelper databaseHelper)
        {
            _databaseHelper = databaseHelper;
        }

        /// <summary>
        /// Returns response if user was successfully added to the database or not
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public ValidateResponse AddUserToDatabase(User user)
        {
            int hasUserBeenAdded = _databaseHelper.AddUserToDatabase(user);

            if (hasUserBeenAdded == 1)
                return new ValidateResponse()
                {
                    Success = true,
                    Message = "You have been successfully registered.\nAn Administrator is waiting to review your details.\nPlease try login in 15 minutes when your details have been authenticated."
                };
            else
                return new ValidateResponse()
                {
                    Success = false,
                    Message = "There was an error registering your account.\n Please contact the support line for help on:\n01234567891"
                };
        }

        /// <summary>
        /// Returns response if date of birth is within -130 - -18 years of todays date
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public ValidateResponse CheckDateOfBirthIntegrity(DateTime value)
        {
            // If they are 18 or over and under the age of 130 then let them proceed
            if (value >= DateTime.Today.AddYears(-130) && value <= DateTime.Today.AddYears(-18))
            {
                return new ValidateResponse()
                {
                    Success = true,
                    Message = "Birth date has sufficient integrity."
                };
            }
            else
            {
                return new ValidateResponse()
                {
                    Success = false,
                    Message = "You must be minumum age of 18 and maximum age of 130."
                };
            }
        }

        /// <summary>
        /// Returns response if Forename , middle name or surname was correct
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public ValidateResponse CheckNameIntegrity(string name, string nameType)
        {
            bool validated = true;
            string message = $"";

            // Some people dont have a middle name
            if (nameType == "Middle Name" && name.Length == 0)
            {
                return new ValidateResponse()
                {
                    Success = true,
                    Message = "No Middle Name To Validate"
                };
            }

            // Name hsa to be minimum of 1 character
            if (name.Length < 1)
            {
                validated = false;
                message += $"{nameType} has to be minimum 1 character long.\n";
            }

            // Name can not contain any digits, only letters
            if (name.Any(char.IsDigit))
            {
                validated = false;
                message += $"{nameType} can not contain any numbers, please write them alphabetically.\n";
            }

            // Only symbol a name can contain is - as some people have 2 names in one
            if (name.Any(c => char.IsSymbol(c) || c != '-' && char.IsLetter(c) == false))
            {
                validated = false;
                message += $"{nameType} can not contain any symbols apart from '-'.\n";
            }

            // Has to at least contain 1 letter
            if (name.Any(char.IsLetter) == false)
            {
                validated = false;
                message += $"{nameType} must contain at least 1 letter.\n";
            }

            // If no errors then success
            if (message == "") message += $"{nameType} has sufficient integrity.";

            return new ValidateResponse()
            {
                Success = validated,
                Message = message
            };
        }

        /// <summary>
        /// Returns response if email address was in correct format
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public ValidateResponse CheckEmailAddressIntegrity(string email)
        {
            // Dont need an email to vote but if you have on then needs to be checked
            if (string.IsNullOrEmpty(email) || string.IsNullOrWhiteSpace(email))
                return new ValidateResponse()
                {
                    Success = true,
                    Message = "No Email to validate."
                };

            // Regular Expression for the format of an email address
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,4})+)$");
            Match match = regex.Match(email);
            if (match.Success)
            {
                return new ValidateResponse()
                {
                    Success = true,
                    Message = "Email Address has sufficient integrity."
                };
            }
            else
            {
                return new ValidateResponse()
                {
                    Success = false,
                    Message = "Email Address could not be parsed."
                };
            }
        }

        /// <summary>
        /// Returns response if mobile or home tel was in correct format
        /// </summary>
        /// <param name="number"></param>
        /// <param name="numberType"></param>
        /// <returns></returns>
        public ValidateResponse CheckContactNumberIntegrity(string number, string numberType)
        {
            number.Trim();

            char[] numArray = number.ToCharArray();

            if (string.IsNullOrEmpty(number))
                return new ValidateResponse()
                {
                    Success = true,
                    Message = $"No {numberType} to be validated."
                };

            // Numbers starting with 0 have 11 characters
            if (numArray[0] == '0')
            {
                if (number.Length == 11)
                {
                    return FinalValidationHasOnlyNumbers(numArray);
                }
                else
                    return new ValidateResponse()
                    {
                        Success = false,
                        Message = $"{numberType}s starting with '0' must be 11 characters long."
                    };
            }
            // numbers starting with a + must be folllowed by a 44 and have 13 characters
            else if (numArray[0] == '+')
            {
                if (numArray[1] == '4' && numArray[2] == '4')
                {
                    if (number.Length == 13)
                    {
                        numArray[0] = '0';
                        return FinalValidationHasOnlyNumbers(numArray);
                    }
                    else
                        return new ValidateResponse()
                        {
                            Success = false,
                            Message = $"{numberType}s starting with '+44' must be 13 characters long."
                        };
                }
                else
                {
                    return new ValidateResponse()
                    {
                        Success = false,
                        Message = $"{numberType}s that start with a '+' must be followed by a '44'."
                    };
                }
            }
            else
            {
                return new ValidateResponse()
                {
                    Success = false,
                    Message = $"{numberType} must start with a '+' or a '0'."
                };
            }

            // Check that it only contains numbers or a +
            ValidateResponse FinalValidationHasOnlyNumbers(char[] charArray)
            {
                if (numArray.All(char.IsDigit))
                    return new ValidateResponse()
                    {
                        Success = true,
                        Message = $"{numberType} has sufficient integrity."
                    };
                else
                    return new ValidateResponse()
                    {
                        Success = false,
                        Message = "Can not contain any symbols or letters after first character (+ / 0)."
                    };
            }
        }

        /// <summary>
        /// Returns response if postcode was in correct format
        /// </summary>
        /// <param name="postcode"></param>
        /// <returns></returns>
        public ValidateResponse CheckPostcodeIntegrity(string postcode)
        {
            postcode.TrimStart();
            postcode.TrimEnd();

            bool containsSpace = false;
            bool containsEnoughLetters = false;
            bool containsEnoughDigits = false;
            bool foundSymbol = false;

            // Needs at least 2 number a space and 3 letters
            if (postcode.Any(char.IsWhiteSpace))
                containsSpace = true;

            int alphabeticalCount = 0;
            int numberCount = 0;

            foreach (char character in postcode.ToCharArray())
            {
                if (char.IsLetter(character))
                    alphabeticalCount++;

                if (char.IsDigit(character))
                    numberCount++;

                if (char.IsLetterOrDigit(character) == false && char.IsWhiteSpace(character) == false)
                    foundSymbol = true;
            }

            if (alphabeticalCount >= 3)
                containsEnoughLetters = true;

            if (numberCount >= 2)
                containsEnoughDigits = true;

            if (containsEnoughLetters && containsEnoughDigits && containsSpace && foundSymbol == false)
            {
                return new ValidateResponse()
                {
                    Success = true,
                    Message = "Postcode has sufficient integrity."
                };
            }
            else
            {
                return new ValidateResponse()
                {
                    Success = false,
                    Message = "Postcode has insufficient integrity.\nPlease be sure to include 2 digits, at least 3 letters, a space and no symbols."
                };
            }
        }

        /// <summary>
        /// Returns response if address was in correct format
        /// </summary>
        /// <param name="address"></param>
        /// <returns></returns>
        public ValidateResponse CheckAddressIntegrity(string address)
        {
            address.TrimStart();
            address.TrimEnd();

            bool hasSpace = false;
            bool hasEnoughCharacters = false;

            if (address.Contains(' '))
                hasSpace = true;

            if (address.Length >= 7)
                hasEnoughCharacters = true;

            if (hasEnoughCharacters && hasSpace)
            {
                return new ValidateResponse()
                {
                    Success = true,
                    Message = "Address has sufficient integrity."
                };
            }
            else
            {
                return new ValidateResponse()
                {
                    Success = false,
                    Message = "Address has insufficient integrity.\nPlease be sure to Include at least 7 characters and white space."
                };
            }
        }

        /// <summary>
        /// Checks if national insurance number is in the correct sequence 
        /// </summary>
        /// <param name="nationalInsuranceNumber"></param>
        /// <param name="updateMode"></param>
        /// <returns></returns>
        public ValidateResponse CheckNationalInsuranceNumberIntegrity(string nationalInsuranceNumber, bool updateMode = false)
        {
            bool validated = true;

            // This is an example provided by the government. Doesn't belong to a real person therefore can't be used.
            if (nationalInsuranceNumber == "For example. 'QQ 12 34 56 C'" || nationalInsuranceNumber == "QQ 12 34 56 C")
            {
                validated = false;
                return new ValidateResponse()
                {
                    Success = validated,
                    Message = "You can not register using the example National Insurance Number.\n Please use only as a reference to the sequence:\n 'QQ 12 34 56 C'."
                };
            }

            // National Insurance Numbers are 13 characters long including spaces.
            if (nationalInsuranceNumber.Length != 13)
            {
                validated = false;
                return new ValidateResponse()
                {
                    Success = validated,
                    Message = "National Insurance Number is composed of 13 characters.\n In the sequence 'QQ 12 34 56 C'.\nPlease include the spaces."
                };
            }

            // Seperate the individual characters from the string into an array of characters.
            char[] niChararray = nationalInsuranceNumber.ToCharArray();

            // The 1st, 2nd and 12th Characters should be letters.
            if (Char.IsLetter(niChararray[0]) == false || Char.IsLetter(niChararray[1]) == false || Char.IsLetter(niChararray[12]) == false) validated = false;

            // The 3rd, 6th, 9th and 12th Characters should be white space.
            if (Char.IsWhiteSpace(niChararray[2]) == false || Char.IsWhiteSpace(niChararray[5]) == false || Char.IsWhiteSpace(niChararray[8]) == false || Char.IsWhiteSpace(niChararray[11]) == false) validated = false;

            // The 4th, 5th, 7th, 8th, 10th and 11th Characters should be a digit.
            if (Char.IsDigit(niChararray[3]) == false || Char.IsDigit(niChararray[4]) == false || Char.IsDigit(niChararray[6]) == false || Char.IsDigit(niChararray[7]) == false || Char.IsDigit(niChararray[9]) == false || Char.IsDigit(niChararray[10]) == false) validated = false;

            // If any of the above checks came back false then sequence of the National Insurance Number is wrong. Display an error.
            if (validated == false)
            {
                return new ValidateResponse()
                {
                    Success = validated,
                    Message = "Please input the National Insurance in the sequence\n 'QQ 12 34 56 C'.\n2 Letters, Space, 2 Numbers, Space, 2 Numbers, Space, \n2 Numbers, Space, 1 Letter"
                };
            }

            // At this point, the National Insurance Number's structure has been verified. 
            // We will check now to see if it already exists in the database.
            // Some users may be awaiting authentication from an administrator and try to register twice.
            // Some may be trying to register as someone else or accidentally put another users in. 

            if (updateMode == false)
            {
                User potentialUser = _databaseHelper.DoesUserAlreadyExist(nationalInsuranceNumber);

                // No user found in database. Return success as can be added into database.
                if (potentialUser == null)
                {
                    return new ValidateResponse()
                    {
                        Success = validated,
                        Message = "National Insurance Number has passed integrity checks.\nNo existing matching records found from the database."
                    };
                }
                else
                {
                    validated = false;

                    // We have found a user. If authenticated tell them to use forgot password if they are trying to re-register.
                    // If they are pending verification, tell them to try again soon.

                    if (potentialUser.Authenticated == 1)
                    {
                        return new ValidateResponse()
                        {
                            Success = validated,
                            Message = "User has already registered with this National Insurance Number.\nIf you have forgotten your details, please use the forgot password on login page."
                        };
                    }
                    else
                    {
                        return new ValidateResponse()
                        {
                            Success = validated,
                            Message = "User has already registered with this National Insurance Number.\nThis account is pending authentication from an Administrator.\nIf this is you, please try to login again soon."
                        };
                    }

                }
            }

            return new ValidateResponse()
            {

                Success = validated,
                Message = "National Insurance Number has passed integrity checks."
            };
        }


        public ValidateResponse CheckPasswordIntegrity(string password)
        {
            PasswordIntegrityRating rating = GetPasswordIntegrityRating(password);

            switch (rating)
            {
                // If there is no data in the password then dont let them proceed
                case PasswordIntegrityRating.Blank:
                    return new ValidateResponse()
                    {
                        Success = false,
                        Message = "Please enter a password which is not blank or whitespace."
                    };
                // Password is too weak , needs to be longer and contain mix of character types, dont let them proceed
                case PasswordIntegrityRating.VeryWeak:
                case PasswordIntegrityRating.Weak:
                    return new ValidateResponse()
                    {
                        Success = false,
                        Message = "Password is too weak.\nPlease add uppercase, lowercase and a symbol.\nMade up of 8 characters."
                    };
                // Password has sufficient integrity and has a mix of character types, let them proceed
                case PasswordIntegrityRating.Medium:
                case PasswordIntegrityRating.Strong:
                    return new ValidateResponse()
                    {
                        Success = true,
                        Message = "Password has sufficient complexity and integrity."
                    };
                default:
                    return null;
            }
        }

        /// <summary>
        /// Returns response if the user details were successfully updated
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public ValidateResponse UpdateUserCard(User user)
        {
            int hasUserBeenUpdated = _databaseHelper.UpdateUser(user);

            if (hasUserBeenUpdated == 1)
            {
                return new ValidateResponse()
                {
                    Success = true,
                    Message = "User has been successfully updated."
                };
            }
            else
            {
                return new ValidateResponse()
                {
                    Success = false,
                    Message = "User update has failed. Please try again."
                };
            }
        }

        /// <summary>
        /// Returns response if the user was successfully authenitcated
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public ValidateResponse SetUserAuthenticated(string userID)
        {
            int hasUserBeenAuthenticated = _databaseHelper.SetUserAuthenticated(userID);

            if (hasUserBeenAuthenticated == 1)
            {
                return new ValidateResponse()
                {
                    Success = true,
                    Message = "User has been successfully authenticated."
                };
            }
            else
            {
                return new ValidateResponse()
                {
                    Success = false,
                    Message = "User authenticated has failed. Please try again."
                };
            }
        }

        /// <summary>
        /// Returns response if both password fields match
        /// </summary>
        /// <param name="password"></param>
        /// <param name="reEnterPassword"></param>
        /// <returns></returns>
        public ValidateResponse CheckPasswordsMatch(string password, string reEnterPassword)
        {
            // If password match , let them proceed
            if (password == reEnterPassword)
            {
                return new ValidateResponse()
                {
                    Success = true,
                    Message = "Passwords match."
                };
            }
            // If passwords dont match, dont let them proceed as in one they have made a spelling mistake
            else
            {
                return new ValidateResponse()
                {
                    Success = false,
                    Message = "Passwords do not match."
                };
            }
        }

        /// <summary>
        /// Gives password a score based on the amount of letters, symbols and cases
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        private PasswordIntegrityRating GetPasswordIntegrityRating(string password)
        {
            int rating = 0;

            // Needs to have minimum of 4 characters
            if (password.Length < 1 || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(password))
                return PasswordIntegrityRating.Blank;
            if (password.Length < 4)
                return PasswordIntegrityRating.VeryWeak;

            // Give them higher rating if password is above 8 and 12 characters
            if (password.Length >= 8)
                rating++;
            if (password.Length >= 12)
                rating++;
            
            // Give them higher rating if they contain a mixture of character types, if they don't then deduct a point
            if (Regex.Match(password, @"\W|_", RegexOptions.ECMAScript).Success) // This is for symbols
                rating++;

            if (Regex.Match(password, "^[a-zA-Z]{1,25}", RegexOptions.ECMAScript).Success)
                rating++;
            else
                rating--;

            return (PasswordIntegrityRating)rating;
        }
    }

    public enum PasswordIntegrityRating
    {
        Blank = 0,
        VeryWeak = 1,
        Weak = 2,
        Medium = 3,
        Strong = 4,
    }
}
