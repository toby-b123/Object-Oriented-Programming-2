﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ElectronicVotingSystemService.Data_Models
{
    public class ValidateResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; }
    }
}
