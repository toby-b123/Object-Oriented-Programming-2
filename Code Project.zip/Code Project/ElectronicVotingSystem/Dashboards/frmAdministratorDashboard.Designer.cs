﻿namespace ElectronicVotingSystem.Dashboards
{
    partial class frmAdministratorDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVote = new System.Windows.Forms.Button();
            this.btnManageElections = new System.Windows.Forms.Button();
            this.btnManageUsers = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnVote
            // 
            this.btnVote.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVote.Location = new System.Drawing.Point(201, 91);
            this.btnVote.Margin = new System.Windows.Forms.Padding(2);
            this.btnVote.Name = "btnVote";
            this.btnVote.Size = new System.Drawing.Size(256, 37);
            this.btnVote.TabIndex = 8;
            this.btnVote.Text = "Vote";
            this.btnVote.UseVisualStyleBackColor = true;
            this.btnVote.Click += new System.EventHandler(this.btnVote_Click);
            // 
            // btnManageElections
            // 
            this.btnManageElections.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManageElections.Location = new System.Drawing.Point(201, 210);
            this.btnManageElections.Margin = new System.Windows.Forms.Padding(2);
            this.btnManageElections.Name = "btnManageElections";
            this.btnManageElections.Size = new System.Drawing.Size(256, 37);
            this.btnManageElections.TabIndex = 9;
            this.btnManageElections.Text = "Manage Elections";
            this.btnManageElections.UseVisualStyleBackColor = true;
            this.btnManageElections.Click += new System.EventHandler(this.btnManageElections_Click);
            // 
            // btnManageUsers
            // 
            this.btnManageUsers.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManageUsers.Location = new System.Drawing.Point(201, 329);
            this.btnManageUsers.Margin = new System.Windows.Forms.Padding(2);
            this.btnManageUsers.Name = "btnManageUsers";
            this.btnManageUsers.Size = new System.Drawing.Size(256, 37);
            this.btnManageUsers.TabIndex = 10;
            this.btnManageUsers.Text = "Verify / Manage Users";
            this.btnManageUsers.UseVisualStyleBackColor = true;
            this.btnManageUsers.Click += new System.EventHandler(this.btnManageUsers_Click);
            // 
            // frmAdministratorDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(656, 457);
            this.Controls.Add(this.btnManageUsers);
            this.Controls.Add(this.btnManageElections);
            this.Controls.Add(this.btnVote);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(672, 496);
            this.MinimumSize = new System.Drawing.Size(672, 496);
            this.Name = "frmAdministratorDashboard";
            this.Text = "Administrator";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnVote;
        private System.Windows.Forms.Button btnManageElections;
        private System.Windows.Forms.Button btnManageUsers;
    }
}