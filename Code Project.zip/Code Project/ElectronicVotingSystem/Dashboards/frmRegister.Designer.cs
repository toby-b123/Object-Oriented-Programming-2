﻿namespace ElectronicVotingSystem.Dashboards
{
    partial class frmRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRegister = new System.Windows.Forms.Button();
            this.lblEnterDetails = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.rtbAddress = new System.Windows.Forms.RichTextBox();
            this.dtpDateOfBirth = new System.Windows.Forms.DateTimePicker();
            this.txtNationalInsuranceNumber = new System.Windows.Forms.TextBox();
            this.lblNationalInsuranceNumber = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtMiddleName = new System.Windows.Forms.TextBox();
            this.lblMiddleName = new System.Windows.Forms.Label();
            this.lblDoPasswordsMatch = new System.Windows.Forms.Label();
            this.txtReEnterPassword = new System.Windows.Forms.TextBox();
            this.lblReEnterPassword = new System.Windows.Forms.Label();
            this.txtForename = new System.Windows.Forms.TextBox();
            this.txtPostcode = new System.Windows.Forms.TextBox();
            this.txtHomeTel = new System.Windows.Forms.TextBox();
            this.txtMobileTel = new System.Windows.Forms.TextBox();
            this.txtEmailAddress = new System.Windows.Forms.TextBox();
            this.txtSurname = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.lblEmailAddress = new System.Windows.Forms.Label();
            this.lblMobileTel = new System.Windows.Forms.Label();
            this.lblHomeTel = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblDateOfBirth = new System.Windows.Forms.Label();
            this.lblSurname = new System.Windows.Forms.Label();
            this.lblForename = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbxAccountType = new System.Windows.Forms.ComboBox();
            this.lblAccountType = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnRegister
            // 
            this.btnRegister.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegister.Location = new System.Drawing.Point(386, 607);
            this.btnRegister.Margin = new System.Windows.Forms.Padding(4);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(100, 25);
            this.btnRegister.TabIndex = 13;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // lblEnterDetails
            // 
            this.lblEnterDetails.AutoSize = true;
            this.lblEnterDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnterDetails.Location = new System.Drawing.Point(175, 26);
            this.lblEnterDetails.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEnterDetails.Name = "lblEnterDetails";
            this.lblEnterDetails.Size = new System.Drawing.Size(203, 24);
            this.lblEnterDetails.TabIndex = 21;
            this.lblEnterDetails.Text = "Please Enter Details:";
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(12, 607);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 25);
            this.btnCancel.TabIndex = 14;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // rtbAddress
            // 
            this.rtbAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbAddress.Location = new System.Drawing.Point(189, 264);
            this.rtbAddress.Margin = new System.Windows.Forms.Padding(4);
            this.rtbAddress.Name = "rtbAddress";
            this.rtbAddress.Size = new System.Drawing.Size(281, 106);
            this.rtbAddress.TabIndex = 8;
            this.rtbAddress.Text = "";
            this.rtbAddress.Click += new System.EventHandler(this.textBoxClickOrTextChangeSetColor);
            this.rtbAddress.TextChanged += new System.EventHandler(this.textBoxClickOrTextChangeSetColor);
            // 
            // dtpDateOfBirth
            // 
            this.dtpDateOfBirth.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDateOfBirth.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDateOfBirth.Location = new System.Drawing.Point(189, 234);
            this.dtpDateOfBirth.Margin = new System.Windows.Forms.Padding(4);
            this.dtpDateOfBirth.Name = "dtpDateOfBirth";
            this.dtpDateOfBirth.Size = new System.Drawing.Size(281, 26);
            this.dtpDateOfBirth.TabIndex = 7;
            this.dtpDateOfBirth.Value = new System.DateTime(2022, 2, 17, 0, 0, 0, 0);
            this.dtpDateOfBirth.ValueChanged += new System.EventHandler(this.textBoxClickOrTextChangeSetColor);
            // 
            // txtNationalInsuranceNumber
            // 
            this.txtNationalInsuranceNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNationalInsuranceNumber.Location = new System.Drawing.Point(189, 28);
            this.txtNationalInsuranceNumber.Margin = new System.Windows.Forms.Padding(4);
            this.txtNationalInsuranceNumber.Name = "txtNationalInsuranceNumber";
            this.txtNationalInsuranceNumber.Size = new System.Drawing.Size(281, 26);
            this.txtNationalInsuranceNumber.TabIndex = 1;
            this.txtNationalInsuranceNumber.Text = "For example. \'QQ 12 34 56 C\'";
            this.txtNationalInsuranceNumber.Click += new System.EventHandler(this.txtNationInsuranceNumber_Click);
            this.txtNationalInsuranceNumber.Leave += new System.EventHandler(this.txtNationInsuranceNumber_Leave);
            // 
            // lblNationalInsuranceNumber
            // 
            this.lblNationalInsuranceNumber.AutoSize = true;
            this.lblNationalInsuranceNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNationalInsuranceNumber.Location = new System.Drawing.Point(8, 31);
            this.lblNationalInsuranceNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNationalInsuranceNumber.Name = "lblNationalInsuranceNumber";
            this.lblNationalInsuranceNumber.Size = new System.Drawing.Size(217, 20);
            this.lblNationalInsuranceNumber.TabIndex = 1;
            this.lblNationalInsuranceNumber.Text = "National Insurance Number:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblAccountType);
            this.groupBox1.Controls.Add(this.cbxAccountType);
            this.groupBox1.Controls.Add(this.txtMiddleName);
            this.groupBox1.Controls.Add(this.lblMiddleName);
            this.groupBox1.Controls.Add(this.lblDoPasswordsMatch);
            this.groupBox1.Controls.Add(this.txtReEnterPassword);
            this.groupBox1.Controls.Add(this.lblReEnterPassword);
            this.groupBox1.Controls.Add(this.txtForename);
            this.groupBox1.Controls.Add(this.txtPostcode);
            this.groupBox1.Controls.Add(this.txtHomeTel);
            this.groupBox1.Controls.Add(this.txtMobileTel);
            this.groupBox1.Controls.Add(this.txtEmailAddress);
            this.groupBox1.Controls.Add(this.txtSurname);
            this.groupBox1.Controls.Add(this.txtPassword);
            this.groupBox1.Controls.Add(this.lblEmailAddress);
            this.groupBox1.Controls.Add(this.lblMobileTel);
            this.groupBox1.Controls.Add(this.lblHomeTel);
            this.groupBox1.Controls.Add(this.lblAddress);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.lblDateOfBirth);
            this.groupBox1.Controls.Add(this.lblSurname);
            this.groupBox1.Controls.Add(this.lblForename);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.lblNationalInsuranceNumber);
            this.groupBox1.Controls.Add(this.txtNationalInsuranceNumber);
            this.groupBox1.Controls.Add(this.dtpDateOfBirth);
            this.groupBox1.Controls.Add(this.rtbAddress);
            this.groupBox1.Location = new System.Drawing.Point(16, 61);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(486, 543);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Registry Information:";
            // 
            // txtMiddleName
            // 
            this.txtMiddleName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMiddleName.Location = new System.Drawing.Point(189, 174);
            this.txtMiddleName.Margin = new System.Windows.Forms.Padding(4);
            this.txtMiddleName.Name = "txtMiddleName";
            this.txtMiddleName.Size = new System.Drawing.Size(281, 26);
            this.txtMiddleName.TabIndex = 5;
            this.txtMiddleName.Click += new System.EventHandler(this.textBoxClickOrTextChangeSetColor);
            this.txtMiddleName.TextChanged += new System.EventHandler(this.textBoxClickOrTextChangeSetColor);
            // 
            // lblMiddleName
            // 
            this.lblMiddleName.AutoSize = true;
            this.lblMiddleName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMiddleName.Location = new System.Drawing.Point(8, 177);
            this.lblMiddleName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMiddleName.Name = "lblMiddleName";
            this.lblMiddleName.Size = new System.Drawing.Size(133, 20);
            this.lblMiddleName.TabIndex = 33;
            this.lblMiddleName.Text = "Middle Name(s):";
            // 
            // lblDoPasswordsMatch
            // 
            this.lblDoPasswordsMatch.AutoSize = true;
            this.lblDoPasswordsMatch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDoPasswordsMatch.ForeColor = System.Drawing.Color.ForestGreen;
            this.lblDoPasswordsMatch.Location = new System.Drawing.Point(186, 114);
            this.lblDoPasswordsMatch.Name = "lblDoPasswordsMatch";
            this.lblDoPasswordsMatch.Size = new System.Drawing.Size(122, 17);
            this.lblDoPasswordsMatch.TabIndex = 31;
            this.lblDoPasswordsMatch.Text = "Passwords match.";
            // 
            // txtReEnterPassword
            // 
            this.txtReEnterPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReEnterPassword.Location = new System.Drawing.Point(189, 88);
            this.txtReEnterPassword.Margin = new System.Windows.Forms.Padding(4);
            this.txtReEnterPassword.Name = "txtReEnterPassword";
            this.txtReEnterPassword.Size = new System.Drawing.Size(281, 26);
            this.txtReEnterPassword.TabIndex = 3;
            this.txtReEnterPassword.UseSystemPasswordChar = true;
            this.txtReEnterPassword.Click += new System.EventHandler(this.textBoxClickOrTextChangeSetColor);
            this.txtReEnterPassword.TextChanged += new System.EventHandler(this.PasswordFields_TextChanged);
            // 
            // lblReEnterPassword
            // 
            this.lblReEnterPassword.AutoSize = true;
            this.lblReEnterPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReEnterPassword.Location = new System.Drawing.Point(8, 91);
            this.lblReEnterPassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblReEnterPassword.Name = "lblReEnterPassword";
            this.lblReEnterPassword.Size = new System.Drawing.Size(160, 20);
            this.lblReEnterPassword.TabIndex = 30;
            this.lblReEnterPassword.Text = "Re-Enter Password:";
            // 
            // txtForename
            // 
            this.txtForename.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtForename.Location = new System.Drawing.Point(189, 144);
            this.txtForename.Margin = new System.Windows.Forms.Padding(4);
            this.txtForename.Name = "txtForename";
            this.txtForename.Size = new System.Drawing.Size(281, 26);
            this.txtForename.TabIndex = 4;
            this.txtForename.Click += new System.EventHandler(this.textBoxClickOrTextChangeSetColor);
            this.txtForename.TextChanged += new System.EventHandler(this.textBoxClickOrTextChangeSetColor);
            // 
            // txtPostcode
            // 
            this.txtPostcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPostcode.Location = new System.Drawing.Point(189, 378);
            this.txtPostcode.Margin = new System.Windows.Forms.Padding(4);
            this.txtPostcode.Name = "txtPostcode";
            this.txtPostcode.Size = new System.Drawing.Size(281, 26);
            this.txtPostcode.TabIndex = 9;
            this.txtPostcode.Click += new System.EventHandler(this.textBoxClickOrTextChangeSetColor);
            this.txtPostcode.TextChanged += new System.EventHandler(this.textBoxClickOrTextChangeSetColor);
            // 
            // txtHomeTel
            // 
            this.txtHomeTel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHomeTel.Location = new System.Drawing.Point(189, 408);
            this.txtHomeTel.Margin = new System.Windows.Forms.Padding(4);
            this.txtHomeTel.MaxLength = 13;
            this.txtHomeTel.Name = "txtHomeTel";
            this.txtHomeTel.Size = new System.Drawing.Size(281, 26);
            this.txtHomeTel.TabIndex = 10;
            this.txtHomeTel.Click += new System.EventHandler(this.textBoxClickOrTextChangeSetColor);
            this.txtHomeTel.TextChanged += new System.EventHandler(this.textBoxClickOrTextChangeSetColor);
            this.txtHomeTel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtContactNumber_KeyPress);
            // 
            // txtMobileTel
            // 
            this.txtMobileTel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMobileTel.Location = new System.Drawing.Point(189, 438);
            this.txtMobileTel.Margin = new System.Windows.Forms.Padding(4);
            this.txtMobileTel.MaxLength = 13;
            this.txtMobileTel.Name = "txtMobileTel";
            this.txtMobileTel.Size = new System.Drawing.Size(281, 26);
            this.txtMobileTel.TabIndex = 11;
            this.txtMobileTel.Click += new System.EventHandler(this.textBoxClickOrTextChangeSetColor);
            this.txtMobileTel.TextChanged += new System.EventHandler(this.textBoxClickOrTextChangeSetColor);
            this.txtMobileTel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtContactNumber_KeyPress);
            // 
            // txtEmailAddress
            // 
            this.txtEmailAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailAddress.Location = new System.Drawing.Point(189, 468);
            this.txtEmailAddress.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmailAddress.Name = "txtEmailAddress";
            this.txtEmailAddress.Size = new System.Drawing.Size(281, 26);
            this.txtEmailAddress.TabIndex = 12;
            this.txtEmailAddress.Click += new System.EventHandler(this.textBoxClickOrTextChangeSetColor);
            this.txtEmailAddress.TextChanged += new System.EventHandler(this.textBoxClickOrTextChangeSetColor);
            // 
            // txtSurname
            // 
            this.txtSurname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSurname.Location = new System.Drawing.Point(189, 204);
            this.txtSurname.Margin = new System.Windows.Forms.Padding(4);
            this.txtSurname.Name = "txtSurname";
            this.txtSurname.Size = new System.Drawing.Size(281, 26);
            this.txtSurname.TabIndex = 6;
            this.txtSurname.TextChanged += new System.EventHandler(this.textBoxClickOrTextChangeSetColor);
            // 
            // txtPassword
            // 
            this.txtPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Location = new System.Drawing.Point(189, 58);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(4);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(281, 26);
            this.txtPassword.TabIndex = 2;
            this.txtPassword.UseSystemPasswordChar = true;
            this.txtPassword.Click += new System.EventHandler(this.textBoxClickOrTextChangeSetColor);
            this.txtPassword.TextChanged += new System.EventHandler(this.PasswordFields_TextChanged);
            // 
            // lblEmailAddress
            // 
            this.lblEmailAddress.AutoSize = true;
            this.lblEmailAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailAddress.Location = new System.Drawing.Point(8, 471);
            this.lblEmailAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmailAddress.Name = "lblEmailAddress";
            this.lblEmailAddress.Size = new System.Drawing.Size(123, 20);
            this.lblEmailAddress.TabIndex = 22;
            this.lblEmailAddress.Text = "Email Address:";
            // 
            // lblMobileTel
            // 
            this.lblMobileTel.AutoSize = true;
            this.lblMobileTel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMobileTel.Location = new System.Drawing.Point(8, 441);
            this.lblMobileTel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMobileTel.Name = "lblMobileTel";
            this.lblMobileTel.Size = new System.Drawing.Size(159, 20);
            this.lblMobileTel.TabIndex = 21;
            this.lblMobileTel.Text = "Mobile Telephone #:";
            // 
            // lblHomeTel
            // 
            this.lblHomeTel.AutoSize = true;
            this.lblHomeTel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHomeTel.Location = new System.Drawing.Point(8, 411);
            this.lblHomeTel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHomeTel.Name = "lblHomeTel";
            this.lblHomeTel.Size = new System.Drawing.Size(155, 20);
            this.lblHomeTel.TabIndex = 20;
            this.lblHomeTel.Text = "Home Telephone #:";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress.Location = new System.Drawing.Point(8, 312);
            this.lblAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(76, 20);
            this.lblAddress.TabIndex = 19;
            this.lblAddress.Text = "Address:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(8, 384);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 20);
            this.label6.TabIndex = 18;
            this.label6.Text = "Postcode:";
            // 
            // lblDateOfBirth
            // 
            this.lblDateOfBirth.AutoSize = true;
            this.lblDateOfBirth.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateOfBirth.Location = new System.Drawing.Point(8, 239);
            this.lblDateOfBirth.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDateOfBirth.Name = "lblDateOfBirth";
            this.lblDateOfBirth.Size = new System.Drawing.Size(114, 20);
            this.lblDateOfBirth.TabIndex = 17;
            this.lblDateOfBirth.Text = "Date Of Birth:";
            // 
            // lblSurname
            // 
            this.lblSurname.AutoSize = true;
            this.lblSurname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSurname.Location = new System.Drawing.Point(8, 207);
            this.lblSurname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSurname.Name = "lblSurname";
            this.lblSurname.Size = new System.Drawing.Size(81, 20);
            this.lblSurname.TabIndex = 16;
            this.lblSurname.Text = "Surname:";
            // 
            // lblForename
            // 
            this.lblForename.AutoSize = true;
            this.lblForename.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblForename.Location = new System.Drawing.Point(8, 147);
            this.lblForename.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblForename.Name = "lblForename";
            this.lblForename.Size = new System.Drawing.Size(89, 20);
            this.lblForename.TabIndex = 15;
            this.lblForename.Text = "Forename:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(8, 61);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 20);
            this.label2.TabIndex = 14;
            this.label2.Text = "Password:";
            // 
            // cbxAccountType
            // 
            this.cbxAccountType.FormattingEnabled = true;
            this.cbxAccountType.Location = new System.Drawing.Point(189, 501);
            this.cbxAccountType.Name = "cbxAccountType";
            this.cbxAccountType.Size = new System.Drawing.Size(281, 28);
            this.cbxAccountType.TabIndex = 34;
            this.cbxAccountType.Visible = false;
            // 
            // lblAccountType
            // 
            this.lblAccountType.AutoSize = true;
            this.lblAccountType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccountType.Location = new System.Drawing.Point(8, 504);
            this.lblAccountType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAccountType.Name = "lblAccountType";
            this.lblAccountType.Size = new System.Drawing.Size(116, 20);
            this.lblAccountType.TabIndex = 35;
            this.lblAccountType.Text = "Account Type:";
            this.lblAccountType.Visible = false;
            // 
            // frmRegister
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(514, 643);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.lblEnterDetails);
            this.Controls.Add(this.btnRegister);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(532, 690);
            this.MinimumSize = new System.Drawing.Size(532, 613);
            this.Name = "frmRegister";
            this.Text = "Register";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Label lblEnterDetails;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.RichTextBox rtbAddress;
        private System.Windows.Forms.DateTimePicker dtpDateOfBirth;
        private System.Windows.Forms.TextBox txtNationalInsuranceNumber;
        private System.Windows.Forms.Label lblNationalInsuranceNumber;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtForename;
        private System.Windows.Forms.TextBox txtPostcode;
        private System.Windows.Forms.TextBox txtHomeTel;
        private System.Windows.Forms.TextBox txtMobileTel;
        private System.Windows.Forms.TextBox txtEmailAddress;
        private System.Windows.Forms.TextBox txtSurname;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label lblEmailAddress;
        private System.Windows.Forms.Label lblMobileTel;
        private System.Windows.Forms.Label lblHomeTel;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblDateOfBirth;
        private System.Windows.Forms.Label lblSurname;
        private System.Windows.Forms.Label lblForename;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtReEnterPassword;
        private System.Windows.Forms.Label lblReEnterPassword;
        private System.Windows.Forms.Label lblDoPasswordsMatch;
        private System.Windows.Forms.TextBox txtMiddleName;
        private System.Windows.Forms.Label lblMiddleName;
        private System.Windows.Forms.Label lblAccountType;
        private System.Windows.Forms.ComboBox cbxAccountType;
    }
}