﻿using ElectronicVotingSystemService.Data_Models;
using ElectronicVotingSystemService.HelperServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ElectronicVotingSystem.Dashboards
{
    public partial class frmRegister : Form
    {
        ValidatorHelper validatorHelper = new ValidatorHelper(new DatabaseHelper());
        private User _user { get; set; }
        public ValidateResponse HasBeenAuthenticated { get; set; } = null;
        public ValidateResponse HasBeenUpdated { get; set; } = null;

        public frmRegister(User user = null, string userMode = "")
        {
            InitializeComponent();

            // Make sure that minimum age is 18 years before today and max age is 130 years from today

            dtpDateOfBirth.MinDate = DateTime.Today.AddYears(-130);
            dtpDateOfBirth.MaxDate = DateTime.Today.AddYears(-18);
            dtpDateOfBirth.Value = dtpDateOfBirth.MaxDate;

            // If user isnt null then we have called the form from the admin dashboard. Populate all fields.
            if (user != null)
            {
                _user = user;

                txtNationalInsuranceNumber.Text = user.NationalInsuranceNumber;
                txtPassword.Text = user.Password;
                txtReEnterPassword.Text = user.Password;
                txtForename.Text = user.Forename;
                txtMiddleName.Text = user.MiddleNames;
                txtSurname.Text = user.Surname;
                dtpDateOfBirth.Value = Convert.ToDateTime(user.DateOfBirth);
                rtbAddress.Text = user.Address;
                txtPostcode.Text = user.Postcode;
                txtHomeTel.Text = user.HomeTel;
                txtMobileTel.Text = user.MobileTel;
                txtEmailAddress.Text = user.EmailAddress;

                // If authenicate mode then disable all controls and re-assign the button text and click behaviour.
                if (userMode == "authenticate")
                {
                    btnRegister.Click -= btnRegister_Click;
                    btnRegister.Click += btnAuthenticate_Click;

                    btnRegister.Text = "Authenticate";

                    txtNationalInsuranceNumber.Enabled = false;
                    txtPassword.Enabled = false;
                    txtReEnterPassword.Enabled = false;
                    txtForename.Enabled = false;
                    txtMiddleName.Enabled = false;
                    txtSurname.Enabled = false;
                    dtpDateOfBirth.Enabled = false;
                    rtbAddress.Enabled = false;
                    txtPostcode.Enabled = false;
                    txtHomeTel.Enabled = false;
                    txtMobileTel.Enabled = false;
                    txtEmailAddress.Enabled = false;
                }
                // If update mode then show the account type and label and change button text and behaviour
                else if (userMode == "update")
                {
                    btnRegister.Click -= btnRegister_Click;
                    btnRegister.Click += btnUpdate_Click;

                    lblAccountType.Visible = true;
                    cbxAccountType.Visible = true;
                    btnRegister.Text = "Update";

                    cbxAccountType.DataSource = Enum.GetValues(typeof(AccountType));
                    cbxAccountType.SelectedItem = _user.AccountType;
                }
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            // handles validation of the users information
            var finalValidationResponse = IsValidationSuccessful(GetFieldsValidationStatus());

            // If validated then add user to database or show an error
            if (finalValidationResponse.Success)
            {
                var successful = validatorHelper.AddUserToDatabase(new User()
                {
                    NationalInsuranceNumber = txtNationalInsuranceNumber.Text,
                    Password = txtPassword.Text,
                    Forename = txtForename.Text,
                    MiddleNames = txtMiddleName.Text,
                    Surname = txtSurname.Text,
                    DateOfBirth = dtpDateOfBirth.Value,
                    Address = rtbAddress.Text,
                    Postcode = txtPostcode.Text,
                    HomeTel = txtHomeTel.Text,
                    MobileTel = txtMobileTel.Text,
                    EmailAddress = txtEmailAddress.Text,
                    AccountType = AccountType.Voter,
                    Authenticated = 0
                });

                if (successful.Success)
                {
                    Hide();
                    MessageBox.Show($"{successful.Message}", "Registration Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Close();
                }
                else
                {
                    MessageBox.Show($"{successful.Message}", "Registration has not been completed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show($"{finalValidationResponse.Message}", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private ValidateResponse IsValidationSuccessful(Dictionary<string, ValidateResponse> verifiedfields)
        {
            // Default message response
            ValidateResponse validity = new ValidateResponse()
            {
                Success = true,
                Message = "All fields have been succesfully validated."
            };

            // THIS CODE INCREMENTS THROUGH THE DICTIONARY OF THE VALIDATE RESPONSES AND CHECKS TO SEE
            // IF THEY ARE SUCCESSFUL OR NOT. GOES FROM TOP TO BOTTOM AND CHANGES COLOR OF CONTROL TO
            // INDICATE THAT THERE IS AN ERROR. IT WILL DISPLAY AN ERROR MESSAGE TO THE USER BASED ON
            // THE VALIDATE RESPONSE.

            if (verifiedfields["isNationalInsuranceNumberCorrect"].Success == false)
            {
                txtNationalInsuranceNumber.BackColor = Color.Red;
                txtNationalInsuranceNumber.ForeColor = Color.White;

                return verifiedfields["isNationalInsuranceNumberCorrect"];
            }
            else
            {
                txtNationalInsuranceNumber.BackColor = SystemColors.Window;
                txtNationalInsuranceNumber.ForeColor = SystemColors.WindowText;

            }

            if (verifiedfields["isPasswordStrongEnough"].Success == false)
            {
                txtPassword.BackColor = Color.Red;
                txtPassword.ForeColor = Color.White;

                return verifiedfields["isPasswordStrongEnough"];
                
            }
            else
            {
                txtPassword.BackColor = SystemColors.Window;
                txtPassword.ForeColor = SystemColors.WindowText;
            }

            if (verifiedfields["doPasswordsMatch"].Success == false)
            {
                PasswordMatchUpdateUI(verifiedfields["doPasswordsMatch"]);

                return verifiedfields["doPasswordsMatch"];
            }
            else
            {
                PasswordMatchUpdateUI(verifiedfields["doPasswordsMatch"]);
            }

            if (verifiedfields["isForenameCorrect"].Success == false)
            {
                txtForename.BackColor = Color.Red;
                txtForename.ForeColor = Color.White;

                return verifiedfields["isForenameCorrect"];
            }
            else
            {
                txtForename.BackColor = SystemColors.Window;
                txtForename.ForeColor = SystemColors.WindowText;
            }

            if (verifiedfields["isMiddlenameCorrect"].Success == false)
            {
                txtMiddleName.BackColor = Color.Red;
                txtMiddleName.ForeColor = Color.White;

                return verifiedfields["isMiddlenameCorrect"];
            }
            else
            {
                txtMiddleName.BackColor = SystemColors.Window;
                txtMiddleName.ForeColor = SystemColors.WindowText;
            }

            if (verifiedfields["isSurnameCorrect"].Success == false)
            {
                txtSurname.BackColor = Color.Red;
                txtSurname.ForeColor = Color.White;

                return verifiedfields["isSurnameCorrect"];
            }
            else
            {
                txtSurname.BackColor = SystemColors.Window;
                txtSurname.ForeColor = SystemColors.WindowText;
            }

            if (verifiedfields["isDateOfBirthInRange"].Success == false)
            {
                dtpDateOfBirth.BackColor = Color.Red;
                dtpDateOfBirth.ForeColor = Color.White;

                return verifiedfields["isDateOfBirthInRange"];
            }
            else
            {
                dtpDateOfBirth.BackColor = SystemColors.Window;
                dtpDateOfBirth.ForeColor = SystemColors.WindowText;
            }

            if (verifiedfields["isAddressValid"].Success == false)
            {
                // There is a bug with Rich Text Box where the text changed
                // event gets called when the ForeColor is changed. Need to unregister
                // and re-register to the event to stop this from occurring.
                rtbAddress.TextChanged -= textBoxClickOrTextChangeSetColor;

                rtbAddress.BackColor = Color.Red;
                rtbAddress.ForeColor = Color.White;

                rtbAddress.TextChanged -= textBoxClickOrTextChangeSetColor;

                return verifiedfields["isAddressValid"];
            }
            else
            {
                rtbAddress.BackColor = SystemColors.Window;
                rtbAddress.ForeColor = SystemColors.WindowText;
            }

            if (verifiedfields["isPostCodeValid"].Success == false)
            {
                txtPostcode.BackColor = Color.Red;
                txtPostcode.ForeColor = Color.White;

                return verifiedfields["isPostCodeValid"];
            }
            else
            {
                txtPostcode.BackColor = SystemColors.Window;
                txtPostcode.ForeColor = SystemColors.WindowText;
            }

            if (verifiedfields["isHomeNoValid"].Success == false)
            {
                txtHomeTel.BackColor = Color.Red;
                txtHomeTel.ForeColor = Color.White;

                return verifiedfields["isHomeNoValid"];
            }
            else
            {
                txtHomeTel.BackColor = SystemColors.Window;
                txtHomeTel.ForeColor = SystemColors.WindowText;
            }

            if (verifiedfields["isMobileNoValid"].Success == false)
            {
                txtMobileTel.BackColor = Color.Red;
                txtMobileTel.ForeColor = Color.White;

                return verifiedfields["isMobileNoValid"];
            }
            else
            {
                txtMobileTel.BackColor = SystemColors.Window;
                txtMobileTel.ForeColor = SystemColors.WindowText;
            }

            if (verifiedfields["isEmailValid"].Success == false)
            {
                txtEmailAddress.BackColor = Color.Red;
                txtEmailAddress.ForeColor = Color.White;

                return verifiedfields["isEmailValid"];
            }
            else
            {
                txtEmailAddress.BackColor = SystemColors.Window;
                txtEmailAddress.ForeColor = SystemColors.WindowText;
            }

            return validity;
        }

        private Dictionary<string, ValidateResponse> GetFieldsValidationStatus(bool updateMode = false)
        {
            Dictionary<string, ValidateResponse> responses = new Dictionary<string, ValidateResponse>();

            // CREATES A DICTIONARY OF VALIDATE RESPONSE OBJECTS AND PUTS CONTROL NAME AS THE KEY.
            // CALLS THE VALIDATIOR SERVICE TO SEPERATE THE UI AND THE SERVICE BACK END CODE FOR 
            // EFFICIENCY AND SECURITY. FOR EACH CONTROL, ADD IN THE VALIDATION STATUS TO DETERMINE THE CONTROL COLOR
            // AND IF WE ARE OKAY TO REGISTER / UPDATE THE USER

            responses.Add("isNationalInsuranceNumberCorrect", validatorHelper.CheckNationalInsuranceNumberIntegrity(txtNationalInsuranceNumber.Text, updateMode));
            responses.Add("isPasswordStrongEnough", validatorHelper.CheckPasswordIntegrity(txtPassword.Text));
            responses.Add("doPasswordsMatch", validatorHelper.CheckPasswordsMatch(txtPassword.Text, txtReEnterPassword.Text));
            responses.Add("isForenameCorrect", validatorHelper.CheckNameIntegrity(txtForename.Text, "Forename"));
            responses.Add("isMiddlenameCorrect", validatorHelper.CheckNameIntegrity(txtMiddleName.Text, "Middle Name"));
            responses.Add("isSurnameCorrect", validatorHelper.CheckNameIntegrity(txtSurname.Text, "Surname"));
            responses.Add("isDateOfBirthInRange", validatorHelper.CheckDateOfBirthIntegrity(dtpDateOfBirth.Value));
            responses.Add("isAddressValid", validatorHelper.CheckAddressIntegrity(rtbAddress.Text));
            responses.Add("isPostCodeValid", validatorHelper.CheckPostcodeIntegrity(txtPostcode.Text));
            responses.Add("isHomeNoValid", validatorHelper.CheckContactNumberIntegrity(txtHomeTel.Text, "Home Tel Number"));
            responses.Add("isMobileNoValid", validatorHelper.CheckContactNumberIntegrity(txtMobileTel.Text, "Mobile Tel Number"));
            responses.Add("isEmailValid", validatorHelper.CheckEmailAddressIntegrity(txtEmailAddress.Text));

            return responses;
        }

        private void txtNationInsuranceNumber_Click(object sender, EventArgs e)
        {
            // When user clicks on the text box, example will disappear 
            if (txtNationalInsuranceNumber.Text == "For example. 'QQ 12 34 56 C'")
            {
                txtNationalInsuranceNumber.Clear();
                txtNationalInsuranceNumber.MaxLength = 13;
            }

            textBoxClickOrTextChangeSetColor(sender, e);
        }

        private void PasswordFields_TextChanged(object sender, EventArgs e)
        {
            // Checks to see if passwords match then update UI.
            PasswordMatchUpdateUI(validatorHelper.CheckPasswordsMatch(txtPassword.Text, txtReEnterPassword.Text));

            textBoxClickOrTextChangeSetColor(sender, e);
        }

        private void PasswordMatchUpdateUI(ValidateResponse doPasswordsMatch)
        {
            // Set tool tip label color to green / red depending on the result.
            if (doPasswordsMatch.Success == true) lblDoPasswordsMatch.ForeColor = Color.ForestGreen;
            if (doPasswordsMatch.Success == false) lblDoPasswordsMatch.ForeColor = Color.Red;

            // Display message as text. Passwords match or do not match.
            lblDoPasswordsMatch.Text = doPasswordsMatch.Message;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtContactNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Check for a naughty character in the KeyDown event.
            if (Regex.IsMatch(e.KeyChar.ToString(), @"[^0-9+\b]"))
            {
                // Stop the character from being entered into the control since it is illegal.
                e.Handled = true;
            }
        }

        private void textBoxClickOrTextChangeSetColor(object sender, EventArgs e)
        {
            // RESETS THE COLOR OF THE TEXT BOX IF IT WASNT VALIDATED BEFORE AND THEY CLICK IT THEN RESET THE COLORS
            var type = sender.GetType();

            if (type == typeof(TextBox))
            {
                ((TextBox)sender).BackColor = SystemColors.Window;
                ((TextBox)sender).ForeColor = SystemColors.WindowText;
            }
            else if (type == typeof(DateTimePicker))
            {
                ((DateTimePicker)sender).BackColor = SystemColors.Window;
                ((DateTimePicker)sender).ForeColor = SystemColors.WindowText;
            }
            else if (type == typeof(RichTextBox))
            {
                ((RichTextBox)sender).BackColor = SystemColors.Window;
                ((RichTextBox)sender).ForeColor = SystemColors.WindowText;
            }
        }

        private void txtNationInsuranceNumber_Leave(object sender, EventArgs e)
        {
            // IF THEY HAVENT POPULATED THE NI NUMBER FIELD THEN WHEN FOCUS LEAVES ADD IN EXAMPLE
            if (txtNationalInsuranceNumber.Text == "")
            {
                txtNationalInsuranceNumber.Text = "For example. 'QQ 12 34 56 C'";
            }
        }

        private void btnAuthenticate_Click(object sender, EventArgs e)
        {
            // FOR THE ADMIN DASHBOARD TO ACCESS THE VALIDATION RESPONSE FOR AUTHENTICATING THE USER
            HasBeenAuthenticated = validatorHelper.SetUserAuthenticated(_user.UserID);

            Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // ADDS IN TRUE FOR UPDATE MODE.
            // USER CAN BE UPDATED BUT WILL STILL KEEP THE SAME NI NUMBER SO WE WANT TO SKIP THE PART WHERE IT
            // CHECKS IF ONE ALREADY EXISTS OR NOT AS IT WILL

            // IF FIELDS HAVE BEEN VALIDATED THEN UPDATE USER
            var finalValidationResponse = IsValidationSuccessful(GetFieldsValidationStatus(true));

            if (finalValidationResponse.Success)
            {

                // FOR THE ADMIN DASHBOARD TO ACCESS THE VALIDATION RESPONSE FOR UPDATING THE USER
                HasBeenUpdated = validatorHelper.UpdateUserCard(new User()
                {
                    UserID = _user.UserID,
                    NationalInsuranceNumber = txtNationalInsuranceNumber.Text,
                    Password = txtPassword.Text,
                    Forename = txtForename.Text,
                    MiddleNames = txtMiddleName.Text,
                    Surname = txtSurname.Text,
                    DateOfBirth = dtpDateOfBirth.Value,
                    Address = rtbAddress.Text,
                    Postcode = txtPostcode.Text,
                    HomeTel = txtHomeTel.Text,
                    MobileTel = txtMobileTel.Text,
                    EmailAddress = txtEmailAddress.Text,
                    AccountType = (AccountType) cbxAccountType.SelectedItem
                });

                Close();
            }
            else
            {
                MessageBox.Show($"{finalValidationResponse.Message}", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
