﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ElectronicVotingSystem.User_Screens;
using ElectronicVotingSystemService.Data_Models;

namespace ElectronicVotingSystem.Dashboards
{
    public partial class frmAdministratorDashboard : Form
    {
        private User _user { get; set; }

        public frmAdministratorDashboard(User user)
        {
            InitializeComponent();
            _user = user;
        }

        private void btnVote_Click(object sender, EventArgs e)
        {
            // Open voting dashboard and let user vote.
            frmVoterDashboard frmVoterDash = new frmVoterDashboard(_user);
            frmVoterDash.TopMost = true;
            frmVoterDash.BringToFront();
            frmVoterDash.ShowDialog();
        }

        private void btnManageElections_Click(object sender, EventArgs e)
        {
            // Open the manage elections form to create delete elections and create ballots
            frmManageElections frmManageElection = new frmManageElections();
            frmManageElection.TopMost = true;
            frmManageElection.BringToFront();
            frmManageElection.ShowDialog();
        }

        private void btnManageUsers_Click(object sender, EventArgs e)
        {
            // Open the manage users form to authenticate or update users
            frmManageUsers frmManageUser = new frmManageUsers();
            frmManageUser.TopMost = true;
            frmManageUser.BringToFront();
            frmManageUser.ShowDialog();

        }
    }
}
