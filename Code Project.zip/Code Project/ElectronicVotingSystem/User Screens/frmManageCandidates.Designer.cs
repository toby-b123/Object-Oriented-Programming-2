﻿namespace ElectronicVotingSystem.User_Screens
{
    partial class frmManageCandidates
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lsbxRecoverCandidate = new System.Windows.Forms.ListBox();
            this.lblRecoverCandidate = new System.Windows.Forms.Label();
            this.btnRecoverCandidate = new System.Windows.Forms.Button();
            this.btnDeleteCandidate = new System.Windows.Forms.Button();
            this.lsbxDeleteCandidate = new System.Windows.Forms.ListBox();
            this.lblDeleteCandidate = new System.Windows.Forms.Label();
            this.btnCreateCandidate = new System.Windows.Forms.Button();
            this.lblCreateCandidate = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtCandidateName = new System.Windows.Forms.TextBox();
            this.lblElectionName = new System.Windows.Forms.Label();
            this.lblCandidateManagementForElection = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lsbxRecoverCandidate
            // 
            this.lsbxRecoverCandidate.FormattingEnabled = true;
            this.lsbxRecoverCandidate.ItemHeight = 16;
            this.lsbxRecoverCandidate.Location = new System.Drawing.Point(839, 143);
            this.lsbxRecoverCandidate.Margin = new System.Windows.Forms.Padding(4);
            this.lsbxRecoverCandidate.Name = "lsbxRecoverCandidate";
            this.lsbxRecoverCandidate.Size = new System.Drawing.Size(311, 356);
            this.lsbxRecoverCandidate.TabIndex = 23;
            // 
            // lblRecoverCandidate
            // 
            this.lblRecoverCandidate.AutoSize = true;
            this.lblRecoverCandidate.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.lblRecoverCandidate.Location = new System.Drawing.Point(905, 98);
            this.lblRecoverCandidate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRecoverCandidate.Name = "lblRecoverCandidate";
            this.lblRecoverCandidate.Size = new System.Drawing.Size(191, 27);
            this.lblRecoverCandidate.TabIndex = 22;
            this.lblRecoverCandidate.Text = "Recover Candidate";
            // 
            // btnRecoverCandidate
            // 
            this.btnRecoverCandidate.Location = new System.Drawing.Point(925, 512);
            this.btnRecoverCandidate.Margin = new System.Windows.Forms.Padding(4);
            this.btnRecoverCandidate.Name = "btnRecoverCandidate";
            this.btnRecoverCandidate.Size = new System.Drawing.Size(152, 28);
            this.btnRecoverCandidate.TabIndex = 21;
            this.btnRecoverCandidate.Text = "Recover Candidate";
            this.btnRecoverCandidate.UseVisualStyleBackColor = true;
            this.btnRecoverCandidate.Click += new System.EventHandler(this.btnRecoverCandidate_Click);
            // 
            // btnDeleteCandidate
            // 
            this.btnDeleteCandidate.Location = new System.Drawing.Point(564, 512);
            this.btnDeleteCandidate.Margin = new System.Windows.Forms.Padding(4);
            this.btnDeleteCandidate.Name = "btnDeleteCandidate";
            this.btnDeleteCandidate.Size = new System.Drawing.Size(152, 28);
            this.btnDeleteCandidate.TabIndex = 20;
            this.btnDeleteCandidate.Text = "Delete Candidate";
            this.btnDeleteCandidate.UseVisualStyleBackColor = true;
            this.btnDeleteCandidate.Click += new System.EventHandler(this.btnDeleteCandidate_Click);
            // 
            // lsbxDeleteCandidate
            // 
            this.lsbxDeleteCandidate.FormattingEnabled = true;
            this.lsbxDeleteCandidate.ItemHeight = 16;
            this.lsbxDeleteCandidate.Location = new System.Drawing.Point(485, 143);
            this.lsbxDeleteCandidate.Margin = new System.Windows.Forms.Padding(4);
            this.lsbxDeleteCandidate.Name = "lsbxDeleteCandidate";
            this.lsbxDeleteCandidate.Size = new System.Drawing.Size(311, 356);
            this.lsbxDeleteCandidate.TabIndex = 19;
            // 
            // lblDeleteCandidate
            // 
            this.lblDeleteCandidate.AutoSize = true;
            this.lblDeleteCandidate.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.lblDeleteCandidate.Location = new System.Drawing.Point(559, 98);
            this.lblDeleteCandidate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDeleteCandidate.Name = "lblDeleteCandidate";
            this.lblDeleteCandidate.Size = new System.Drawing.Size(174, 27);
            this.lblDeleteCandidate.TabIndex = 18;
            this.lblDeleteCandidate.Text = "Delete Candidate";
            // 
            // btnCreateCandidate
            // 
            this.btnCreateCandidate.Location = new System.Drawing.Point(215, 512);
            this.btnCreateCandidate.Margin = new System.Windows.Forms.Padding(4);
            this.btnCreateCandidate.Name = "btnCreateCandidate";
            this.btnCreateCandidate.Size = new System.Drawing.Size(152, 28);
            this.btnCreateCandidate.TabIndex = 15;
            this.btnCreateCandidate.Text = "Create Candidate";
            this.btnCreateCandidate.UseVisualStyleBackColor = true;
            this.btnCreateCandidate.Click += new System.EventHandler(this.btnCreateCandidate_Click);
            // 
            // lblCreateCandidate
            // 
            this.lblCreateCandidate.AutoSize = true;
            this.lblCreateCandidate.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreateCandidate.Location = new System.Drawing.Point(200, 98);
            this.lblCreateCandidate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCreateCandidate.Name = "lblCreateCandidate";
            this.lblCreateCandidate.Size = new System.Drawing.Size(175, 27);
            this.lblCreateCandidate.TabIndex = 17;
            this.lblCreateCandidate.Text = "Create Candidate";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.txtCandidateName);
            this.panel1.Controls.Add(this.lblElectionName);
            this.panel1.Location = new System.Drawing.Point(136, 146);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(311, 352);
            this.panel1.TabIndex = 16;
            // 
            // txtCandidateName
            // 
            this.txtCandidateName.Location = new System.Drawing.Point(97, 26);
            this.txtCandidateName.Margin = new System.Windows.Forms.Padding(4);
            this.txtCandidateName.Name = "txtCandidateName";
            this.txtCandidateName.Size = new System.Drawing.Size(205, 22);
            this.txtCandidateName.TabIndex = 2;
            // 
            // lblElectionName
            // 
            this.lblElectionName.AutoSize = true;
            this.lblElectionName.Location = new System.Drawing.Point(4, 30);
            this.lblElectionName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblElectionName.Name = "lblElectionName";
            this.lblElectionName.Size = new System.Drawing.Size(49, 17);
            this.lblElectionName.TabIndex = 1;
            this.lblElectionName.Text = "Name:";
            // 
            // lblCandidateManagementForElection
            // 
            this.lblCandidateManagementForElection.AutoSize = true;
            this.lblCandidateManagementForElection.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.lblCandidateManagementForElection.Location = new System.Drawing.Point(327, 11);
            this.lblCandidateManagementForElection.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCandidateManagementForElection.Name = "lblCandidateManagementForElection";
            this.lblCandidateManagementForElection.Size = new System.Drawing.Size(366, 27);
            this.lblCandidateManagementForElection.TabIndex = 24;
            this.lblCandidateManagementForElection.Text = "Candidate Management for election: ";
            // 
            // frmManageCandidates
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1285, 554);
            this.Controls.Add(this.lblCandidateManagementForElection);
            this.Controls.Add(this.lsbxRecoverCandidate);
            this.Controls.Add(this.lblRecoverCandidate);
            this.Controls.Add(this.btnRecoverCandidate);
            this.Controls.Add(this.btnDeleteCandidate);
            this.Controls.Add(this.lsbxDeleteCandidate);
            this.Controls.Add(this.lblDeleteCandidate);
            this.Controls.Add(this.btnCreateCandidate);
            this.Controls.Add(this.lblCreateCandidate);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmManageCandidates";
            this.Text = "frmManageCandidates";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lsbxRecoverCandidate;
        private System.Windows.Forms.Label lblRecoverCandidate;
        private System.Windows.Forms.Button btnRecoverCandidate;
        private System.Windows.Forms.Button btnDeleteCandidate;
        private System.Windows.Forms.ListBox lsbxDeleteCandidate;
        private System.Windows.Forms.Label lblDeleteCandidate;
        private System.Windows.Forms.Button btnCreateCandidate;
        private System.Windows.Forms.Label lblCreateCandidate;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtCandidateName;
        private System.Windows.Forms.Label lblElectionName;
        private System.Windows.Forms.Label lblCandidateManagementForElection;
    }
}