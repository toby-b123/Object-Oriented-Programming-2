﻿using ElectronicVotingSystemService.Data_Models;
using ElectronicVotingSystemService.HelperServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ElectronicVotingSystem.User_Screens
{
    public partial class frmManageElections : Form
    {
        IDatabaseHelper databaseHelper = new DatabaseHelper();

        public frmManageElections()
        {
            InitializeComponent();

            RefreshListBoxes();
        }

        private void RefreshListBoxes()
        {
            lsbxDeleteElection.DataSource = null;
            lsbxManageCandidates.DataSource = null;
            lsbxRecoverElection.DataSource = null;

            List<Election> notDeletedElections = databaseHelper.GetAllElectionsNotDeleted();

            if (notDeletedElections != null)
            {
                // If we have active elections - display the data within the listBox control.
                lsbxManageCandidates.DataSource = notDeletedElections;
                lsbxManageCandidates.DisplayMember = "ElectionName";
                lsbxManageCandidates.ValueMember = "ElectionInstanceID";
            }

            List<Election> deletedElections = databaseHelper.GetAllElectionsDeleted();

            if (deletedElections != null)
            {
                // If we have deleted elections - display the data within the listBox control.
                lsbxRecoverElection.DataSource = deletedElections;
                lsbxRecoverElection.DisplayMember = "ElectionName";
                lsbxRecoverElection.ValueMember = "ElectionInstanceID";
            }

            List<Election> activeElections = databaseHelper.GetAllElectionsNotDeleted();

            if (activeElections != null)
            {
                // If we have active elections - display the data within the listBox control.
                lsbxDeleteElection.DataSource = activeElections;
                lsbxDeleteElection.DisplayMember = "ElectionName";
                lsbxDeleteElection.ValueMember = "ElectionInstanceID";
            }
        }

        private void btnCreateElection_Click(object sender, EventArgs e)
        {
            if ((string.IsNullOrEmpty(txtElectionName.Text) || string.IsNullOrWhiteSpace(txtElectionName.Text)) == false)
            {
                // IF START DATE IS BEFORE END DATE THEN PROCEED , IF NOT DISPLAY AN ERROR
                if (dtpElectionEndDate.Value > dtpElectionStartDate.Value)
                {
                    // IF ELECTION NAME ALREADY EXISTS THEN DISPLAY AN ERROR - IF NOT THEN ADD OT DATABASE
                    if (databaseHelper.DoesElectionNameAlreadyExist(txtElectionName.Text) == false)
                    {
                        int added = databaseHelper.AddElectionToDatabase(new Election() 
                        {
                            ElectionName = txtElectionName.Text,
                            ElectionStartDate = dtpElectionStartDate.Value.ToString(),
                            ElectionEndDate = dtpElectionEndDate.Value.ToString(),
                            Deleted = 0
                        });

                        // IF SUCCESSFUL THEN LET THE USER KNOW OR IF IT HAS FAILED
                        if (added == 1)
                        {
                            MessageBox.Show($"Election has been successfully added to the database.", "Election creation Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            dtpElectionStartDate.Value = DateTime.Today;
                            dtpElectionEndDate.Value = DateTime.Today;
                            txtElectionName.Text = "";
                        }
                        else
                        {
                            MessageBox.Show($"There has been an unknown error adding the election to the database.\nPlease check the information provided and try again.", "Election creation failed.", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show($"There is already an election with this name in the database.\nPlease try another name.", "Election name error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show($"The election start date must be before the election end date.", "Election dates error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show($"Please add a name to the election.", "Election name error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            RefreshListBoxes();
        }

        private void btnDeleteElection_Click(object sender, EventArgs e)
        {
            Election deleteElection;

            if (lsbxDeleteElection.SelectedValue.GetType() == typeof(Election))
                deleteElection = (Election)lsbxDeleteElection.SelectedValue;
            else
                deleteElection = databaseHelper.GetElectionFromElectionID(lsbxDeleteElection.SelectedValue.ToString());

            // GET INSTANCE OF THE ELECTION FROM THE DATABASE , BASED OFF THE SELECTED CANDIDATE ON THE LIST BOX ON THE UI FORM

            if (deleteElection != null)
            {
                int hasBeenDeleted = databaseHelper.DeleteElection(deleteElection.ElectionInstanceID);

                // IF ELECTION DELETION WAS SUCCESSFUL THEN LET THE USER KNOW OR IF IT HAS FAILED

                if (hasBeenDeleted == 1)
                {
                    MessageBox.Show($"Election has been deleted from the database.", "Election deletion Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show($"Election has not been deleted from the database.\nPlease try again soon.", "Election deletion failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show($"Election could not be found from the database.\nPlease try again soon.", "Election deletion failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            RefreshListBoxes();
        }

        private void btnRecoverElections_Click(object sender, EventArgs e)
        {
            Election recoverElection;

            // GET INSTANCE OF THE ELECTION FROM THE DATABASE , BASED OFF THE SELECTED CANDIDATE ON THE LIST BOX ON THE UI FORM

            if (lsbxRecoverElection.SelectedValue.GetType() == typeof(Election))
                recoverElection = (Election)lsbxRecoverElection.SelectedValue;
            else
                recoverElection = databaseHelper.GetElectionFromElectionID(lsbxRecoverElection.SelectedValue.ToString());

            if (recoverElection != null)
            {
                int hasBeenRecovered = databaseHelper.RecoverElection(recoverElection.ElectionInstanceID);

                // IF ELECTION DELETION WAS SUCCESSFUL THEN LET THE USER KNOW OR IF IT HAS FAILED

                if (hasBeenRecovered == 1)
                {
                    MessageBox.Show($"Election has been recovered from the database.", "Election recovery Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show($"Election has not been recovered from the database.\nPlease try again soon.", "Election recovery failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show($"Election could not be found from the database.\nPlease try again soon.", "Election recovery failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            RefreshListBoxes();
        }

        private void btnManageBallot_Click(object sender, EventArgs e)
        {
            Election manageElection;

            // GET INSTANCE OF THE ELECTION FROM THE DATABASE , BASED OFF THE SELECTED CANDIDATE ON THE LIST BOX ON THE UI FORM
            if (lsbxManageCandidates.SelectedValue.GetType() == typeof(Election))
                manageElection = (Election)lsbxManageCandidates.SelectedValue;
            else
                manageElection = databaseHelper.GetElectionFromElectionID(lsbxManageCandidates.SelectedValue.ToString());

            // IF WE RETREIEVED IT FROM THE DATABASE THEN OPEN BALLOT FORM - IF NOT THEN DISPLAY ERROR
            if (manageElection != null)
            {
                frmManageCandidates frmManageBallot = new frmManageCandidates(manageElection);

                Hide();

                frmManageBallot.TopMost = true;
                frmManageBallot.BringToFront();
                frmManageBallot.ShowDialog();

                Show();
            }
            else
            {
                MessageBox.Show($"Election could not be found from the database.\nPlease try again soon.", "Election recovery failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            RefreshListBoxes();
        }
    }
}
