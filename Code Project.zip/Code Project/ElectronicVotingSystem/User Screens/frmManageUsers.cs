﻿using ElectronicVotingSystem.Dashboards;
using ElectronicVotingSystemService.Data_Models;
using ElectronicVotingSystemService.HelperServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ElectronicVotingSystem.User_Screens
{
    public partial class frmManageUsers : Form
    {
        IDatabaseHelper databaseHelper = new DatabaseHelper();
        public frmManageUsers()
        {
            InitializeComponent();

            RefreshListBoxes();
        }

        private void RefreshListBoxes()
        {
            lsbxPendingAuthorisation.DataSource = null;
            lsbxUpdateUserCard.DataSource = null;

            List<User> nonAuthenticatedUsers = databaseHelper.GetNonAuthenticatedUsers();

            // IF WE HAVE USERS TO AUTHENTICATE THEN ADD THEM TO THE LIST BOXES

            if (nonAuthenticatedUsers != null)
            {
                lsbxPendingAuthorisation.DataSource = nonAuthenticatedUsers;
                lsbxPendingAuthorisation.DisplayMember = "NationalInsuranceNumber";
                lsbxPendingAuthorisation.ValueMember = "UserID";
            }
            
            List<User> authenticatedUsers = databaseHelper.GetAuthenticatedUsers();

            // IF WE HAVE USERS WHICH ARE AUTHENTICATED THEN ADD THEM TO LIST BOXES

            if (authenticatedUsers != null)
            {
                lsbxUpdateUserCard.DataSource = authenticatedUsers;
                lsbxUpdateUserCard.DisplayMember = "NationalInsuranceNumber";
                lsbxUpdateUserCard.ValueMember = "UserID";
            }
        }

        private void btnUpdateUser_Click(object sender, EventArgs e)
        {
            User toBeUpdatedUser;



            if (((Button)sender).Name == "btnUpdateUser")
            {
                if (lsbxUpdateUserCard.SelectedValue.GetType() == typeof(User))
                    toBeUpdatedUser = (User)lsbxUpdateUserCard.SelectedValue;
                else
                    toBeUpdatedUser = databaseHelper.GetUserFromUserID(lsbxUpdateUserCard.SelectedValue.ToString());

                // GET INSTANCE OF THE USER FROM THE DATABASE , BASED OFF THE SELECTED USER ON THE LIST BOX ON THE UI FORM

                if (toBeUpdatedUser != null)
                {
                    // OPEN REGISTER FORM IN UPDATE MODE
                    frmRegister frmUpdateUser = new frmRegister(toBeUpdatedUser, "update");
                    frmUpdateUser.TopMost = true;
                    frmUpdateUser.BringToFront();
                    frmUpdateUser.ShowDialog();

                    // WHEN FORM HAS BEEN CLOSED THEN CHECK THE VALIDATE REPSPONSE AND TELL USER IF IT WAS SUCCESSFUL
                    if (frmUpdateUser.HasBeenUpdated == null)
                    {
                    }
                    else if (frmUpdateUser.HasBeenUpdated.Success)
                    {
                        MessageBox.Show($"{frmUpdateUser.HasBeenUpdated.Message}", "User update Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else if (frmUpdateUser.HasBeenUpdated.Success == false)
                    {
                        MessageBox.Show($"{frmUpdateUser.HasBeenUpdated.Message}", "User update failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show($"User could not be found from the database.\nPlease try again soon.", "User update failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            if (((Button)sender).Name == "btnAuthorise")
            {
                if (lsbxPendingAuthorisation.SelectedValue.GetType() == typeof(User))
                    toBeUpdatedUser = (User)lsbxPendingAuthorisation.SelectedValue;
                else
                    toBeUpdatedUser = databaseHelper.GetUserFromUserID(lsbxPendingAuthorisation.SelectedValue.ToString());

                // GET INSTANCE OF THE USER FROM THE DATABASE , BASED OFF THE SELECTED USER ON THE LIST BOX ON THE UI FORM

                if (toBeUpdatedUser != null)
                {
                    // OPEN REGISTER FORM IN AUTHENTICATE MODE
                    frmRegister frmAuthoriseUser = new frmRegister(toBeUpdatedUser, "authenticate");
                    frmAuthoriseUser.TopMost = true;
                    frmAuthoriseUser.BringToFront();
                    frmAuthoriseUser.ShowDialog();

                    // WHEN FORM HAS BEEN CLOSED THEN CHECK THE VALIDATE REPSPONSE AND TELL USER IF IT WAS SUCCESSFUL
                    if (frmAuthoriseUser.HasBeenAuthenticated == null)
                    {
                    }
                    else if (frmAuthoriseUser.HasBeenAuthenticated.Success)
                    {
                        MessageBox.Show($"{frmAuthoriseUser.HasBeenAuthenticated.Message}", "User authentication Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else if (frmAuthoriseUser.HasBeenAuthenticated.Success == false)
                    {
                        MessageBox.Show($"{frmAuthoriseUser.HasBeenAuthenticated.Message}", "User authentication failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show($"User could not be found from the database.\nPlease try again soon.", "User authentication failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            RefreshListBoxes();
        }
    }
}
