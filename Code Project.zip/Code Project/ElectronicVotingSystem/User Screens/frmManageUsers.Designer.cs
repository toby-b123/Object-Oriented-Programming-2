﻿namespace ElectronicVotingSystem.User_Screens
{
    partial class frmManageUsers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lsbxPendingAuthorisation = new System.Windows.Forms.ListBox();
            this.lsbxUpdateUserCard = new System.Windows.Forms.ListBox();
            this.btnAuthorise = new System.Windows.Forms.Button();
            this.btnUpdateUser = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.label1.Location = new System.Drawing.Point(64, 39);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(224, 27);
            this.label1.TabIndex = 3;
            this.label1.Text = "Pending Authorisation";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.label2.Location = new System.Drawing.Point(437, 39);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(182, 27);
            this.label2.TabIndex = 5;
            this.label2.Text = "Update User Card";
            // 
            // lsbxPendingAuthorisation
            // 
            this.lsbxPendingAuthorisation.FormattingEnabled = true;
            this.lsbxPendingAuthorisation.ItemHeight = 16;
            this.lsbxPendingAuthorisation.Location = new System.Drawing.Point(33, 81);
            this.lsbxPendingAuthorisation.Margin = new System.Windows.Forms.Padding(4);
            this.lsbxPendingAuthorisation.Name = "lsbxPendingAuthorisation";
            this.lsbxPendingAuthorisation.Size = new System.Drawing.Size(311, 372);
            this.lsbxPendingAuthorisation.TabIndex = 7;
            // 
            // lsbxUpdateUserCard
            // 
            this.lsbxUpdateUserCard.FormattingEnabled = true;
            this.lsbxUpdateUserCard.ItemHeight = 16;
            this.lsbxUpdateUserCard.Location = new System.Drawing.Point(384, 81);
            this.lsbxUpdateUserCard.Margin = new System.Windows.Forms.Padding(4);
            this.lsbxUpdateUserCard.Name = "lsbxUpdateUserCard";
            this.lsbxUpdateUserCard.Size = new System.Drawing.Size(311, 372);
            this.lsbxUpdateUserCard.TabIndex = 8;
            // 
            // btnAuthorise
            // 
            this.btnAuthorise.Location = new System.Drawing.Point(115, 480);
            this.btnAuthorise.Name = "btnAuthorise";
            this.btnAuthorise.Size = new System.Drawing.Size(137, 31);
            this.btnAuthorise.TabIndex = 9;
            this.btnAuthorise.Text = "Authorise User";
            this.btnAuthorise.UseVisualStyleBackColor = true;
            this.btnAuthorise.Click += new System.EventHandler(this.btnUpdateUser_Click);
            // 
            // btnUpdateUser
            // 
            this.btnUpdateUser.Location = new System.Drawing.Point(462, 480);
            this.btnUpdateUser.Name = "btnUpdateUser";
            this.btnUpdateUser.Size = new System.Drawing.Size(147, 31);
            this.btnUpdateUser.TabIndex = 10;
            this.btnUpdateUser.Text = "Update User Details";
            this.btnUpdateUser.UseVisualStyleBackColor = true;
            this.btnUpdateUser.Click += new System.EventHandler(this.btnUpdateUser_Click);
            // 
            // frmManageUsers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(740, 538);
            this.Controls.Add(this.btnUpdateUser);
            this.Controls.Add(this.btnAuthorise);
            this.Controls.Add(this.lsbxUpdateUserCard);
            this.Controls.Add(this.lsbxPendingAuthorisation);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmManageUsers";
            this.Text = "frmManageUsers";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox lsbxPendingAuthorisation;
        private System.Windows.Forms.ListBox lsbxUpdateUserCard;
        private System.Windows.Forms.Button btnAuthorise;
        private System.Windows.Forms.Button btnUpdateUser;
    }
}