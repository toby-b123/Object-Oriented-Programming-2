﻿using ElectronicVotingSystemService.Data_Models;
using ElectronicVotingSystemService.HelperServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ElectronicVotingSystem.User_Screens
{
    public partial class frmManageCandidates : Form
    {
        IDatabaseHelper databaseHelper = new DatabaseHelper();
        private Election _election { get; set; }

        public frmManageCandidates(Election election)
        {
            InitializeComponent();

            _election = election;

            // SETS THE NAME OF THE ELECTION FOR USER CLARITY
            lblCandidateManagementForElection.Text += election.ElectionName;

            RefreshListBoxes();
        }

        private void RefreshListBoxes()
        { 
            // CLEARS AND SETS THE DATA IN THE FORMS LIST BOXES TO DISPLAY DELETEABLE AND RECOVERABLE CANDIDATES
            lsbxDeleteCandidate.DataSource = null;
            lsbxRecoverCandidate.DataSource = null;

            List<Candidate> nonDeletedCandidates = databaseHelper.GetCandidatesFromElection(_election.ElectionInstanceID);

            if (nonDeletedCandidates != null)
            {
                lsbxDeleteCandidate.DataSource = nonDeletedCandidates;
                lsbxDeleteCandidate.DisplayMember = "CandidateName";
                lsbxDeleteCandidate.ValueMember = "CandidateID";
            }


            List<Candidate> deletedCandidates = databaseHelper.GetDeletedCandidatesFromElection(_election.ElectionInstanceID);

            if (deletedCandidates != null)
            {
                lsbxRecoverCandidate.DataSource = deletedCandidates;
                lsbxRecoverCandidate.DisplayMember = "CandidateName";
                lsbxRecoverCandidate.ValueMember = "CandidateID";
            }
        }


        private void btnCreateCandidate_Click(object sender, EventArgs e)
        {
            // CANDIDATE MUST HAVE A NAME
            if (string.IsNullOrEmpty(txtCandidateName.Text) || string.IsNullOrWhiteSpace(txtCandidateName.Text))
            {
                MessageBox.Show($"Please add data into the candidate name field.", "Candidate Creation Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                // CANDIDATE NAME CANT BE DUPLICATED IN AN ELECTION
                var doesCandidateNameExist = databaseHelper.GetCandidateFromElectionIDCandidateName(_election.ElectionInstanceID, txtCandidateName.Text);

                if (doesCandidateNameExist == null)
                {
                    // IF NAME DOESNT EXIST THEN ADD TO DATABASE. LET USER KNOW IF IT SUCCEEDED OR NOT
                    int addCandidateToElection = databaseHelper.AddCandidateToElection(_election.ElectionInstanceID, txtCandidateName.Text);
                    
                    if (addCandidateToElection == 1)
                    {
                        MessageBox.Show($"Candidate has successfully been added to the election.", "Candidate Creation Succeeded", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // RESET NAME FIELD WHEN USER HAS BEEN ADDED TO PREVENT THEM TRYING TO ADD DUPLICATES
                        txtCandidateName.Text = "";
                    }
                    else
                    {
                        MessageBox.Show($"Error adding candidate to election.\nPlease try again soon.", "Candidate Creation Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show($"Candidate already exists in the election.\nPlease use a different name.", "Candidate Creation Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            RefreshListBoxes();
        }

        private void btnDeleteCandidate_Click(object sender, EventArgs e)
        {
            Candidate deleteCandidate;

            // GET INSTANCE OF THE CANDIDATE FROM THE DATABASE , BASED OFF THE SELECTED CANDIDATE ON THE LIST BOX ON THE UI FORM
            if (lsbxDeleteCandidate.SelectedValue.GetType() == typeof(Election))
                deleteCandidate = (Candidate)lsbxDeleteCandidate.SelectedValue;
            else
                deleteCandidate = databaseHelper.GetCandidateFromElectionIDCandidateID(_election.ElectionInstanceID, lsbxDeleteCandidate.SelectedValue.ToString());

            if (deleteCandidate != null)
            {
                // IF CANDIDATE DELETION WAS SUCCESSFUL THEN LET THE USER KNOW OR IF IT HAS FAILED
                int hasBeenDeleted = databaseHelper.DeleteCandidateFromElection(deleteCandidate.CandidateID);

                if (hasBeenDeleted == 1)
                {
                    MessageBox.Show($"Candidate has been deleted from the election.", "Candidte deletion Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show($"Candidate has not been deleted from the election.\nPlease try again soon.", "Candidate deletion failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show($"Candidate could not be found from the database.\nPlease try again soon.", "Candidate deletion failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            RefreshListBoxes();
        }

        private void btnRecoverCandidate_Click(object sender, EventArgs e)
        {
            Candidate recoverCandidate;

            // GET INSTANCE OF THE CANDIDATE FROM THE DATABASE , BASED OFF THE SELECTED CANDIDATE ON THE LIST BOX ON THE UI FORM

            if (lsbxRecoverCandidate.SelectedValue.GetType() == typeof(Election))
                recoverCandidate = (Candidate)lsbxRecoverCandidate.SelectedValue;
            else
                recoverCandidate = databaseHelper.GetCandidateFromElectionIDCandidateID(_election.ElectionInstanceID, lsbxRecoverCandidate.SelectedValue.ToString());

            if (recoverCandidate != null)
            {
                // IF CANDIDATE RECOVERY WAS SUCCESSFUL THEN LET THE USER KNOW OR IF IT HAS FAILED
                int hasBeenRecovered = databaseHelper.RecoverCandidate(recoverCandidate.CandidateID);

                if (hasBeenRecovered == 1)
                {
                    MessageBox.Show($"Candidate has been recovered from the election.", "Candidate recovery Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show($"Candidate has not been recovered from the election.\nPlease try again soon.", "Candidate recovery failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show($"Candidate could not be found from the election.\nPlease try again soon.", "Candidate recovery failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            RefreshListBoxes();
        }
    }
}
