﻿namespace ElectronicVotingSystem.User_Screens
{
    partial class frmManageElections
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnCreateElection = new System.Windows.Forms.Button();
            this.lblElectionName = new System.Windows.Forms.Label();
            this.txtElectionName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dtpElectionStartDate = new System.Windows.Forms.DateTimePicker();
            this.dtpElectionEndDate = new System.Windows.Forms.DateTimePicker();
            this.lsbxDeleteElection = new System.Windows.Forms.ListBox();
            this.btnDeleteElection = new System.Windows.Forms.Button();
            this.btnRecoverElections = new System.Windows.Forms.Button();
            this.btnManageBallot = new System.Windows.Forms.Button();
            this.lsbxRecoverElection = new System.Windows.Forms.ListBox();
            this.lblRecoverElections = new System.Windows.Forms.Label();
            this.lsbxManageCandidates = new System.Windows.Forms.ListBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.dtpElectionEndDate);
            this.panel1.Controls.Add(this.dtpElectionStartDate);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.txtElectionName);
            this.panel1.Controls.Add(this.lblElectionName);
            this.panel1.Location = new System.Drawing.Point(21, 69);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(234, 287);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(69, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "Create Election";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.label2.Location = new System.Drawing.Point(338, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 21);
            this.label2.TabIndex = 3;
            this.label2.Text = "Delete Election";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.label3.Location = new System.Drawing.Point(822, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(216, 21);
            this.label3.TabIndex = 5;
            this.label3.Text = "Manage Ballot per Election";
            // 
            // btnCreateElection
            // 
            this.btnCreateElection.Location = new System.Drawing.Point(80, 391);
            this.btnCreateElection.Name = "btnCreateElection";
            this.btnCreateElection.Size = new System.Drawing.Size(114, 23);
            this.btnCreateElection.TabIndex = 0;
            this.btnCreateElection.Text = "Create Election";
            this.btnCreateElection.UseVisualStyleBackColor = true;
            this.btnCreateElection.Click += new System.EventHandler(this.btnCreateElection_Click);
            // 
            // lblElectionName
            // 
            this.lblElectionName.AutoSize = true;
            this.lblElectionName.Location = new System.Drawing.Point(3, 24);
            this.lblElectionName.Name = "lblElectionName";
            this.lblElectionName.Size = new System.Drawing.Size(38, 13);
            this.lblElectionName.TabIndex = 1;
            this.lblElectionName.Text = "Name:";
            // 
            // txtElectionName
            // 
            this.txtElectionName.Location = new System.Drawing.Point(73, 21);
            this.txtElectionName.Name = "txtElectionName";
            this.txtElectionName.Size = new System.Drawing.Size(155, 20);
            this.txtElectionName.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 125);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "End Date:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 75);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Start Date:";
            // 
            // dtpElectionStartDate
            // 
            this.dtpElectionStartDate.Location = new System.Drawing.Point(73, 69);
            this.dtpElectionStartDate.Name = "dtpElectionStartDate";
            this.dtpElectionStartDate.Size = new System.Drawing.Size(155, 20);
            this.dtpElectionStartDate.TabIndex = 8;
            // 
            // dtpElectionEndDate
            // 
            this.dtpElectionEndDate.Location = new System.Drawing.Point(73, 119);
            this.dtpElectionEndDate.Name = "dtpElectionEndDate";
            this.dtpElectionEndDate.Size = new System.Drawing.Size(155, 20);
            this.dtpElectionEndDate.TabIndex = 9;
            // 
            // lsbxDeleteElection
            // 
            this.lsbxDeleteElection.FormattingEnabled = true;
            this.lsbxDeleteElection.Location = new System.Drawing.Point(283, 66);
            this.lsbxDeleteElection.Name = "lsbxDeleteElection";
            this.lsbxDeleteElection.Size = new System.Drawing.Size(234, 290);
            this.lsbxDeleteElection.TabIndex = 6;
            // 
            // btnDeleteElection
            // 
            this.btnDeleteElection.Location = new System.Drawing.Point(342, 391);
            this.btnDeleteElection.Name = "btnDeleteElection";
            this.btnDeleteElection.Size = new System.Drawing.Size(114, 23);
            this.btnDeleteElection.TabIndex = 10;
            this.btnDeleteElection.Text = "Delete Election";
            this.btnDeleteElection.UseVisualStyleBackColor = true;
            this.btnDeleteElection.Click += new System.EventHandler(this.btnDeleteElection_Click);
            // 
            // btnRecoverElections
            // 
            this.btnRecoverElections.Location = new System.Drawing.Point(613, 391);
            this.btnRecoverElections.Name = "btnRecoverElections";
            this.btnRecoverElections.Size = new System.Drawing.Size(114, 23);
            this.btnRecoverElections.TabIndex = 11;
            this.btnRecoverElections.Text = "Recover Elections";
            this.btnRecoverElections.UseVisualStyleBackColor = true;
            this.btnRecoverElections.Click += new System.EventHandler(this.btnRecoverElections_Click);
            // 
            // btnManageBallot
            // 
            this.btnManageBallot.Location = new System.Drawing.Point(863, 391);
            this.btnManageBallot.Name = "btnManageBallot";
            this.btnManageBallot.Size = new System.Drawing.Size(139, 23);
            this.btnManageBallot.TabIndex = 12;
            this.btnManageBallot.Text = "Manage Ballot for Election";
            this.btnManageBallot.UseVisualStyleBackColor = true;
            this.btnManageBallot.Click += new System.EventHandler(this.btnManageBallot_Click);
            // 
            // lsbxRecoverElection
            // 
            this.lsbxRecoverElection.FormattingEnabled = true;
            this.lsbxRecoverElection.Location = new System.Drawing.Point(548, 66);
            this.lsbxRecoverElection.Name = "lsbxRecoverElection";
            this.lsbxRecoverElection.Size = new System.Drawing.Size(234, 290);
            this.lsbxRecoverElection.TabIndex = 14;
            // 
            // lblRecoverElections
            // 
            this.lblRecoverElections.AutoSize = true;
            this.lblRecoverElections.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.lblRecoverElections.Location = new System.Drawing.Point(598, 30);
            this.lblRecoverElections.Name = "lblRecoverElections";
            this.lblRecoverElections.Size = new System.Drawing.Size(135, 21);
            this.lblRecoverElections.TabIndex = 13;
            this.lblRecoverElections.Text = "Recover Election";
            // 
            // lsbxManageCandidates
            // 
            this.lsbxManageCandidates.FormattingEnabled = true;
            this.lsbxManageCandidates.Location = new System.Drawing.Point(814, 66);
            this.lsbxManageCandidates.Name = "lsbxManageCandidates";
            this.lsbxManageCandidates.Size = new System.Drawing.Size(234, 290);
            this.lsbxManageCandidates.TabIndex = 15;
            // 
            // frmManageElections
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1070, 450);
            this.Controls.Add(this.lsbxManageCandidates);
            this.Controls.Add(this.lsbxRecoverElection);
            this.Controls.Add(this.lblRecoverElections);
            this.Controls.Add(this.btnManageBallot);
            this.Controls.Add(this.btnRecoverElections);
            this.Controls.Add(this.btnDeleteElection);
            this.Controls.Add(this.lsbxDeleteElection);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnCreateElection);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Name = "frmManageElections";
            this.Text = "frmManageElections";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtpElectionEndDate;
        private System.Windows.Forms.DateTimePicker dtpElectionStartDate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtElectionName;
        private System.Windows.Forms.Label lblElectionName;
        private System.Windows.Forms.Button btnCreateElection;
        private System.Windows.Forms.ListBox lsbxDeleteElection;
        private System.Windows.Forms.Button btnDeleteElection;
        private System.Windows.Forms.Button btnRecoverElections;
        private System.Windows.Forms.Button btnManageBallot;
        private System.Windows.Forms.ListBox lsbxRecoverElection;
        private System.Windows.Forms.Label lblRecoverElections;
        private System.Windows.Forms.ListBox lsbxManageCandidates;
    }
}