# ElectronicVotingSystemOOP
VERY IMPORTANT PLEASE READ!! : 
The code will not initially work due to a bug with downloading Visual Studio written source code.
Go to the directory download folder where you can see the 3 project folders.
Highlight every folder and file (or press Ctrl + A) and right click > Properties > Untick Hidden and Untick Read Only and press Apply.
If you do not do this, the DLLs and Database will not allow access. So please make sure to do this before opening the code!!


![image](https://user-images.githubusercontent.com/99662460/154301815-ece75d16-feee-4277-a986-84706c37d1ef.png)


See below for login details for user accounts:

Login details for each user:

Admin: NI-1  admin123
Auditor: NI-2  audit123
Voter1: NI-3  voter123
Voter2: NI-4  voter2123
